from Vision import SaliencyMap
# from Vision.cam import GradCam
# from Statistics import rmsf, RMSD
def main():
    print(SaliencyMap, )

if __name__ == '__main__':
    main()

